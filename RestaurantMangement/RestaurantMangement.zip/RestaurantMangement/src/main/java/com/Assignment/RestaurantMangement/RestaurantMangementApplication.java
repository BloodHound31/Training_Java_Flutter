package com.Assignment.RestaurantMangement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantMangementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantMangementApplication.class, args);
	}

}
