package com.Assignment.RestaurantMangement.Entities;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;



@Document(collection = "restaurantTable")
public class Tables {
	
	
	@Id
	private String tableNumber;
	@Field("Is Reserved")
	private Boolean isReserved;
	@Field("Number Of People")
	private int tableQuantity;
	
	@Field("Restaurant")
	@DBRef
	private Restaurant restaurant;
	
	public Tables() {
		super();
		// TODO Auto-generated constructor stub
	}


	//public Tables(String tableNumber, String restaurantId, Boolean isReserved, int tableQuantity) {
		//super();
		//this.tableNumber = tableNumber;
		//this.restaurantId = restaurantId;
		//this.isReserved = isReserved;
		//this.tableQuantity = tableQuantity;
	//}

	

	public String getTableNumber() {
		return tableNumber;
	}


	public Tables(String tableNumber, Boolean isReserved, int tableQuantity, Restaurant restaurant) {
		super();
		this.tableNumber = tableNumber;
		this.isReserved = isReserved;
		this.tableQuantity = tableQuantity;
		this.restaurant = restaurant;
	}


	public void setTableNumber(String tableNumber) {
		this.tableNumber = tableNumber;
	}
	

	public Boolean getIsReserved() {
		return isReserved;
	}


	public void setIsReserved(Boolean isReserved) {
		this.isReserved = isReserved;
	}


	public int getTableQuantity() {
		return tableQuantity;
	}


	public void setTableQuantity(int tableQuantity) {
		this.tableQuantity = tableQuantity;
	}


	public Restaurant getRestaurant() {
		return restaurant;
	}


	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}


	@Override
	public String toString() {
		return "Tables [tableNumber=" + tableNumber + ", isReserved=" + isReserved + ", tableQuantity=" + tableQuantity
				+ ", restaurant=" + restaurant + "]";
	}
	
	


   
	
	

}
