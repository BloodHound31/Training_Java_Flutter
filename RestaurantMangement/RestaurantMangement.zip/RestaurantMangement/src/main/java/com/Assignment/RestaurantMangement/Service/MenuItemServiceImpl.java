package com.Assignment.RestaurantMangement.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.Assignment.RestaurantMangement.Dao.MenuItemDao;
import com.Assignment.RestaurantMangement.Entities.MenuItems;


@Service
public class MenuItemServiceImpl implements MenuItemService{

	
	@Autowired
	private MenuItemDao menuItemsDao;

	
	
	
	@Override
	public List<MenuItems> getMenuItems() {
		// TODO Auto-generated method stub
		return menuItemsDao.findAll();
	}

	@Override
	public Optional<MenuItems> getMenuItem(String menuItemsId) {
		// TODO Auto-generated method stub
		return menuItemsDao.findById(menuItemsId);
	}

	@Override
	public MenuItems addMenuItem(MenuItems menuItems) {
		// TODO Auto-generated method stub
		
		return menuItemsDao.save(menuItems);
	}

	@Override
	public MenuItems updateMenuItems(MenuItems menuItems) {
		// TODO Auto-generated method stub
		return menuItemsDao.save(menuItems);
	}

	@Override
	public void deleteMenuItems(String menuItemsId) {
		// TODO Auto-generated method stub
		menuItemsDao.deleteById(menuItemsId);;
	}



}
