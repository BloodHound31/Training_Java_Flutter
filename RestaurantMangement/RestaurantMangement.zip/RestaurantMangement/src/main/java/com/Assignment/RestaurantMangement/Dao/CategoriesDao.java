package com.Assignment.RestaurantMangement.Dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.Assignment.RestaurantMangement.Entities.Categories;


public interface CategoriesDao extends MongoRepository<Categories, String>{

}
