package com.Assignment.RestaurantMangement.Dao;




import org.springframework.data.mongodb.repository.MongoRepository;

import com.Assignment.RestaurantMangement.Entities.MenuItems;

public interface MenuItemDao extends MongoRepository<MenuItems, String>{
	
	
}
