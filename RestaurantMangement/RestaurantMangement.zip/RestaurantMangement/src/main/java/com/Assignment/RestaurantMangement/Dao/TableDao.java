package com.Assignment.RestaurantMangement.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.Assignment.RestaurantMangement.Entities.Tables;



public interface TableDao extends MongoRepository<Tables, String>{
	
	List<Tables> findByRestaurantId(String restaurantId);
	
	 Optional<Tables> findByIsReserved(boolean condition);

}
