package com.Assignment.RestaurantMangement.Dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.Assignment.RestaurantMangement.Entities.Cuisines;

public interface CuisinesDao extends MongoRepository<Cuisines, String>{

}
